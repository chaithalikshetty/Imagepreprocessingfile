import java.util.Scanner;
public class Contrast_stretch_demo{

static Scanner in=new Scanner(System.in);

  public cont_st() {
 	int row,column;
 	
 	
 	//System.out.println("enter the dimension(m x n): row ,column    :");
 	
 	/*row=in.nextInt();
 	column=in.nextInt();
 	int image[][]=new int [100][100];
 	System.out.println("enter the image pixel values:   ");
 	 image=getInput(row,column);*/
 	 display(image);
 	 contras_str(image,row,column);

 }
 
 public static int [][] getInput(int row,int column ){
 	int result[][]=new int [row][column];
 	for(int i=0;i<row;i++){
 		for(int j=0;j<column;j++){
 			result[i][j]=in.nextInt();

 		}
 	}
 	return result;

 }

 public static void display(int image[][]){
 	int r=image.length;
 	int h=image[0].length;
 	System.out.println("The image :    ");
 	for(int i=0;i<r;i++){
 		for(int j=0;j<h;j++){
 			System.out.print(image[i][j]+"  ");
 		}
 		System.out.println();
 	}

 }

public static void contras_str(int image[][],int row,int column){
	double result[][]=new double [row][column];
	
	int max=getMax(image);
	int min=getMin(image);

 	for(int i=0;i<row;i++){
 		for(int j=0;j<column;j++){
 			result[i][j]=(((double)image[i][j]-min)/(max-min)*256);
 		}
 	}
 	System.out.println("the contrast stretched image  :   ");
 	for(int i=0;i<row;i++){
 		for(int j=0;j<column;j++){
 			System.out.print((int)result[i][j]+"  ");
 		}
 		System.out.println();
 	}
 }
public static int getMax(int image[][]){
	int max=image[0][0];
	int r=image.length;
	int h=image[0].length;
	for(int i=0;i<r;i++){
 		for(int j=0;j<h;j++){
 			if(max<image[i][j]){
 				max=image[i][j];
 			}
 		}
 		

}
System.out.println("max  : "+max);
return max;

}
public static  int getMin(int image[][]){
	int min=image[0][0];
	int r=image.length;
	int h=image[0].length;
	for(int i=0;i<r;i++){
 		for(int j=0;j<h;j++){
 			if(min>image[i][j]){
 				min=image[i][j];
 			}
 		}
 		
}
System.out.println("min  : "+min);
return min;
}






}