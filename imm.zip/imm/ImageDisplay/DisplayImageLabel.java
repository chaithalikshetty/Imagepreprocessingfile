import java.awt.*;

import java.awt.event.*;

import javax.swing.*;

public class DisplayImageLabel extends JPanel {
  
	public DisplayImageLabel() {
		// Create and add a JLabel
		JLabel plainLabel = new JLabel("Plain Small Label");
		ImageIcon imageIcon = new ImageIcon("award.jpg"); 
		plainLabel.setIcon(imageIcon);
		add(plainLabel); 
		
  }
  public static void main (String args[]) {
    
	  JFrame f = new JFrame ("Label Example");
		JPanel j = new DisplayImageLabel();
		JScrollPane sp = new JScrollPane(j);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.getContentPane().add (sp, BorderLayout.CENTER);
		f.setSize (1350, 700);
		//f.setSize(getToolKit())
		//f.pack();
		f.show();
  }
}
