import javax.imageio.ImageIO;

import java.awt.*;
import javax.swing.*;
 public class Slider_t{
 	
	public void slide(){
	 final JFrame frame = new JFrame("brightening ");
 
        // create a slider
        JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 250, 10);
        slider.setMinorTickSpacing(5);
        slider.setMajorTickSpacing(20);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        slider.setLabelTable(slider.createStandardLabels(20));
 
        //
        frame.setLayout(new FlowLayout());
      //  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 200);
        frame.getContentPane().add(slider);
        frame.setVisible(true);
    }
}