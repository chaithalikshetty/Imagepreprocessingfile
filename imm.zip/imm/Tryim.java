import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.AbstractButton;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.event.ActionEvent;


public class Tryim extends JFrame implements ActionListener{

    private JMenuBar mnu_bar;
    private JMenu mnu_file,mnu_edit;
    private JMenuItem  mnu_open, mnu_save, mnu_exit;
    private JTextArea txt_doc;

 Tryim(String title){

        super(title);
        
        Container contentPane = getContentPane();

        mnu_bar = new JMenuBar();

        mnu_file = new JMenu("File");
        mnu_edit = new JMenu("Edit");

       
        mnu_open = new JMenuItem("Open");
        mnu_open.addActionListener(this);
        mnu_save = new JMenuItem("Save");
        mnu_save.addActionListener(this);
        mnu_exit = new JMenuItem("Close");
        mnu_exit.addActionListener(this);

        
        mnu_file.add(mnu_open);
        mnu_file.add(mnu_save);
        mnu_file.addSeparator();
        mnu_file.add(mnu_exit);

        mnu_bar.add(mnu_file);

        setJMenuBar(mnu_bar);
        
       // txt_doc = new JTextArea();
        contentPane.add(new JScrollPane(), BorderLayout.CENTER);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        setSize(900,750);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        
         if(e.getSource()==mnu_open) {
            JFileChooser fc=new JFileChooser("E:\\");
            fc.showOpenDialog(this);
            File f=fc.getSelectedFile();
            BufferedReader br=null;
            try {
                br=new BufferedReader(new FileReader(f));
                String msg=br.readLine();
                while(msg!=null) {
                    
                    txt_doc.append(msg+"\n");
                    msg=br.readLine();
                }
            }
            catch(Exception ex){
                
            }
            finally {
                try {
                    if(br!=null) {
                        br.close();
                    }
                }
                catch(Exception ex) {
                    
                }
            }
        }
        else if(e.getSource()==mnu_save) {
            JFileChooser fc1=new JFileChooser("D:\\");
            fc1.showSaveDialog(this);
            File f=fc1.getSelectedFile();
            BufferedWriter br=null;
            try {
                br=new BufferedWriter(new FileWriter(f));
                
                String msg = null;
                br.write(txt_doc.getText());
                br.newLine();
                br.close();
            }
            catch(Exception ex){
                
            }
            finally {
                try {
                    if(br!=null) {
                        br.close();
                    }
                }
                catch(Exception ex) {
                    
                }
            }
        }
        else if(e.getSource()==mnu_exit) {
            System.exit(0);
        }
    }
    public static void main(String[] args) {
        new Tryim("Image Processing ToolKIt");
    }
}