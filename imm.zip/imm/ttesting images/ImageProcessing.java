package org.mano.example3;

import java.awt.*;
import java.io.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class ImageProcessing extends JFrame {
   private static final long serialVersionUID = 1L;
   private final JPanel buttonPanel;
   private ImagePanel imagePanel;

   private final JButton artButton;
   private final JButton gsButton;
   private final JButton loadButton;
   private final JButton saveButton;

   public ImageProcessing() {
      try {
         imagePanel = new ImagePanel(ImageIO.read(new File
            ("/home/mano/Pictures/cartoons/tangled.jpg")));
      } catch (IOException e) {
         e.printStackTrace();
      }
      

      getContentPane().add(imagePanel, BorderLayout.CENTER);
      getContentPane().add(buttonPanel, BorderLayout.NORTH);
   }

   
      

   public static void main(String[] args) {
      // start application
      ImageProcessing ip = new ImageProcessing();
      ip.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      ip.setSize(450, 300);
      ip.setVisible(true);
   }
}