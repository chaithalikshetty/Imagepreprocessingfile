import javax.imageio.ImageIO;
import java.io.IOException;
import java.awt.*;
import javax.swing.*;

public class Tool_im{
	public static void main(String[] args){
		 new Imageprocess_Tool("Image Processing ToolKIt");

		
	}
}