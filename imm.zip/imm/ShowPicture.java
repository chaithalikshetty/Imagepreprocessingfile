import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.image.BufferedImage;
class ShowPicture 
{
 public ShowPicture() {
 	public void loadImage(BufferedImage image){
  JFrame frame = new JFrame();
  ImageIcon icon = new ImageIcon("image");
  JLabel label = new JLabel(icon);
  //frame.add(label);
  
  frame.pack();
  frame.setVisible(true);
  frame.setSize(500, 200);
        frame.getContentPane().add(label);
        frame.setVisible(true);
}
 }
}