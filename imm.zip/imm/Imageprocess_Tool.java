import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.event.*;


public class Imageprocess_Tool extends JFrame implements ActionListener{

    private JMenuBar mnu_bar;
    private JMenu mnu_file,mnu_arit,mnu_edit,mnu_tool,mnu_enh,mnu_mask,mnu_color,mnu_edge;
    private JMenuItem  mnu_open, mnu_save, mnu_exit,mnu_cut,mnu_copy,mnu_paste,mnu_blend,mnu_add,mnu_bri,mnu_rgb,mnu_hsi,mnu_cmy,mnu_gray,mnu_bin,mnu_cont,mnu_hist,mnu_smo,mnu_prew,mnu_sob,mnu_lap;
    

 Imageprocess_Tool(String title){

        super(title);
        
        Container contentPane = getContentPane();

        //for storing image
        BufferedImage image = null; 
  
        mnu_bar = new JMenuBar();
        //file menu

        mnu_file = new JMenu("File");
        mnu_edit = new JMenu("Edit");
        mnu_tool = new JMenu("Tools");
       
       // menu items in file
        mnu_open = new JMenuItem("Open");
        mnu_open.addActionListener(this);
        mnu_save = new JMenuItem("Save");
        mnu_save.addActionListener(this);
        mnu_exit = new JMenuItem("Close");
        mnu_exit.addActionListener(this);

        // menu items in edit
        mnu_cut = new JMenuItem("Cut");
        mnu_cut.addActionListener(this);
        mnu_copy = new JMenuItem("Copy");
        mnu_cut.addActionListener(this);
        mnu_paste = new JMenuItem("paste");
        mnu_paste.addActionListener(this);

        //menu items in tools
        mnu_arit = new JMenu("Arithmetic operator");
        mnu_arit.addActionListener(this);
        mnu_enh = new JMenu("Image Enhancement");
        mnu_enh.addActionListener(this);
        mnu_mask = new JMenu("Masking");
        mnu_mask.addActionListener(this);
        mnu_color = new JMenu("Color Process");
        mnu_color.addActionListener(this);

        //sub menu
        mnu_blend = new JMenuItem("Blending");
        mnu_blend.addActionListener(this);
        mnu_add = new JMenuItem("Add");
        mnu_add.addActionListener(this);
        mnu_bri = new JMenuItem("Brightening");
        mnu_bri.addActionListener(this);
        mnu_cont = new JMenuItem("Contrast Stretching");
        mnu_cont.addActionListener(this);
        mnu_hist = new JMenuItem("Histogram Equalization");
        mnu_hist.addActionListener(this);
        mnu_smo = new JMenuItem("Smoothening");
        mnu_smo.addActionListener(this);
        mnu_edge = new JMenu("Edge Detection");
        mnu_edge.addActionListener(this);
        mnu_prew = new JMenuItem("Prewitt");
        mnu_prew.addActionListener(this);
        mnu_sob = new JMenuItem("Sobel");
        mnu_sob.addActionListener(this);
        mnu_lap = new JMenuItem("Laplacian");
        mnu_lap.addActionListener(this);
        mnu_rgb = new JMenuItem("Convert to RGB");
        mnu_rgb.addActionListener(this);
        mnu_hsi = new JMenuItem("Convert to HSI");
        mnu_hsi.addActionListener(this);
        mnu_cmy = new JMenuItem("Convert to CMY");
        mnu_cmy.addActionListener(this);
        mnu_gray = new JMenuItem("Convert to Gray");
        mnu_gray.addActionListener(this);
        mnu_bin = new JMenuItem("Convert to Binary");
        mnu_bin.addActionListener(this);

        //adding to file
        mnu_file.add(mnu_open);
        mnu_file.add(mnu_save);
        mnu_file.addSeparator();
        mnu_file.add(mnu_exit);

        //adding to edit
        mnu_edit.add(mnu_cut);
        mnu_edit.add(mnu_copy);
        mnu_edit.add(mnu_paste);

        //adding to tool
        mnu_tool.add(mnu_arit);
        mnu_tool.add(mnu_enh);
        mnu_tool.add(mnu_mask);
        mnu_tool.add(mnu_color);

         //adding sub to arith
         mnu_arit.add(mnu_add);
         mnu_arit.add(mnu_blend);

        //adding sub to enhance
         mnu_enh.add(mnu_bri);
         mnu_enh.add(mnu_cont);
         mnu_enh.add(mnu_hist);

        //adding sub to mask
         mnu_mask.add(mnu_smo);
         mnu_mask.add(mnu_edge);
         //adding sub to edge
         mnu_edge.add(mnu_prew);
         mnu_edge.add(mnu_sob);
         mnu_edge.add(mnu_lap);

         //adiing sub to color
         mnu_color.add(mnu_rgb);
         mnu_color.add(mnu_hsi);
         mnu_color.add(mnu_cmy);
         mnu_color.add(mnu_gray);
         mnu_color.add(mnu_bin);

          //adding to menu bar
        mnu_bar.add(mnu_file);
        mnu_bar.add(mnu_edit);
        mnu_bar.add(mnu_tool);

        setJMenuBar(mnu_bar);
      
             
        contentPane.add(new JScrollPane(), BorderLayout.CENTER);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        setSize(900,750);
        setVisible(true);

      
             
    }


    @Override
    public void actionPerformed(ActionEvent e)
    {
        //BufferedImage image ;
         if(e.getSource()==mnu_exit) {

            System.exit(0);
        }
       
         if(e.getSource()==mnu_open){
            JFileChooser fc = new JFileChooser("C:\\Users\\SOIS\\Desktop\\imaging lab");
            fc.showOpenDialog(this);
            File f = fc.getSelectedFile();
            //BufferedImage br=null;

           ImagePanel shim= new ImagePanel("f");
         shim.loadImage(f.getAbsolutePath());
         shim.pixvalue();
     
         


           
          

        }
         if(e.getSource()==mnu_save){
             
                 

            
        }
        if(e.getSource()==mnu_cut){

        }
        if(e.getSource()==mnu_copy){

        }
        if(e.getSource()==mnu_paste){

        }
        if(e.getSource()==mnu_blend){

        }
        if(e.getSource()==mnu_add){

        }
        if(e.getSource()==mnu_bri){
            Slider_t slbar=new Slider_t();
            slbar.slide();
        }
       
        if(e.getSource()==mnu_cont){
           // Contrast_stretch_demo contras=new Contrast_stretch_demo();
            //contras.cont_st();

        }
        if(e.getSource()==mnu_hist){

        }
        if(e.getSource()==mnu_smo){

        }
        if(e.getSource()==mnu_prew){

        }
        if(e.getSource()==mnu_sob){

        }
        if(e.getSource()==mnu_lap){

        }
        if(e.getSource()==mnu_rgb){

        }
        if(e.getSource()==mnu_hsi){

        }
        if(e.getSource()==mnu_cmy){

        }
        if(e.getSource()==mnu_gray){

        }
        if(e.getSource()==mnu_bin){

        }



    }
    
}