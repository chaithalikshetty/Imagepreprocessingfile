/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackdemo;

/**
 *
 * @author hp
 */
public class Stackdm {
    private int top,size;
    private int array[];
    
        void createNew(int size){
        top=-1;
        array=new int[size];
        this.size=size;
        
    }
    int push(int item){
        if(top==size-1){
            System.out.println("overflow...........");
            return 1;
        }
        array[++top]=item;
     return 1;   
    }
    
    int pop(){
        if(top==-1){
            empty();
            return 1;
        }
        else
            
        return array[top--];
    }
    void display(){
         if(top==-1){
            empty();
            return;
                    
        }
         System.out.println("Stack elements ........");
         for(int i=0;i<=top;i++){
             System.out.println(array[i]);
         }
                 
    }
    void empty(){
        System.out.println("underflow...........");
        
    }
}
