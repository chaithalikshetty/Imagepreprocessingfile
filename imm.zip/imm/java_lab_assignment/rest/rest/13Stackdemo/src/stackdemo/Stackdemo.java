/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//13

package stackdemo;
import java.util.Scanner;
/**
 *
 * @author hp
 */
public class Stackdemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int item,size,opt=1;
        Stackdm ob=new Stackdm(); 
        int []arr ;
         String choice="";
         
         System.out.println("enter the no. of elements to be inserted");
                  Scanner in=new Scanner(System.in);
                  size=in.nextInt();
                  ob.createNew(size);
                   System.out.println("Stack ...............");
                  while(opt!=0){
                   System.out.println(" 1:push   2:pop    3:display    0:exit");
                    opt=in.nextInt();
                   
                   switch(opt){
                       case 1: 
                              System.out.println("enter the element to be inserted");
                              item=in.nextInt();
                              ob.push(item);
                              break;
                       case 2:                          
                                  
                                   ob.pop();
                                   break;
                                   
                       case 3:
                                   
                                   ob.display();
                                   break;
                       case 0:
                                break;
                   }
                
            }
    }
    
}
