/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shapedemo;

/**
 *
 * @author hp
 */
public class Circle extends Shape {
    private double radius ;
    Circle(){
        radius =1.0;
    }
    Circle(double radius){
        this.radius=radius;
    }
    Circle(double radius,String color,boolean filled){
        super(color,filled);
                this.radius=radius;
    }
    public double getradius(){
        return radius;
    }
    public void setRadius(double radius){
		this.radius = radius;
	}

    public double getarea(){
       double area= 3.14*radius*radius;
       return area;
    }
    public double getperimeter(){
        double perimeter=2*3.14*radius;
        return perimeter;
    }
    
	@Override
	public String toString(){

		return super.toString() + "radius : " + radius;
	}
    
    
}
