/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shapedemo;

/**
 *
 * @author hp
 */
public class Square extends Rectangle {
    Square(){
        double side=5;
        
    }
    Square(double side){
        super(side,side);
    }
    Square(double side,String color,boolean filled){
        super(side,side);
    }
    public double getside(){
        return 1;
    }
    public void setside(double side){
             
       
    }
    @Override
    public void setwidth(double side){
        
    }
    @Override
    public void setlength(double side){
        
    }
    @Override
	public String toString(){

		return super.toString() ;
	}
}
