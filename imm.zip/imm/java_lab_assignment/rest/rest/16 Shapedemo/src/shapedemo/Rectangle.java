/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shapedemo;

/**
 *
 * @author hp
 */
public class Rectangle extends Shape {
    private double length;
    private double width;
    Rectangle(){
       length=1.0;
       width=1.0;
    }
    Rectangle(double length,double width){
        this.length=length;
        this.width=width;
       }
    Rectangle(double length,double width,String color,boolean filled){
         super(color,filled);
        this.length=length;
        this.width=width;
    }
    public double getwidth(){
        return width;
    }
    public void setwidth(double width){
		this.width = width;
	}
    public double getlength(){
        return length;
    }
    public void setlength(double length){
		this.length = length;
	}
    public double getarea(){
       double area= length*width;
       return area;
    }
    public double getperimeter(){
        double perimeter=2*(length+width);
        return perimeter;
    }
    @Override
	public String toString(){

		return super.toString() + "  length : " + length +"  width : "+width;
	}
    
}
