/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//16

package shapedemo;
import java.util.Scanner;
/**
 *
 * @author hp
 */
public class Shapedemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
        String choice="";
        double radius,length,width,side;
        do{
       Circle ob=new Circle();
       System.out.println("area = "+ob.getarea()+"  perimeter : "+ob.getperimeter());
       System.out.println(ob);
       
       System.out.println("enter the radius");
       Scanner in=new Scanner(System.in);
       radius=in.nextDouble();
       Circle ob1=new Circle(radius);
       System.out.println("area = "+ob1.getarea()+"  perimeter : "+ob1.getperimeter());
       System.out.println(ob1);
       
       System.out.println("enter the radius");
       in=new Scanner(System.in);
       radius=in.nextDouble();
       Circle ob2=new Circle(radius,"green",true);
       System.out.println("area = "+ob2.getarea()+"  perimeter : "+ob2.getperimeter());
       System.out.println(ob2);
       
       Rectangle rob=new Rectangle();
       System.out.println("area : "+rob.getarea()+"  perimeter : "+rob.getperimeter());
       System.out.println(rob);
       
       System.out.println("enter the length and width");
       in=new Scanner(System.in);
       length=in.nextDouble();
       width=in.nextDouble();
       Rectangle rob1=new Rectangle(length,width);
       System.out.println("area : "+rob1.getarea()+"  perimeter : "+rob1.getperimeter());
       System.out.println(rob1);
       
       System.out.println("enter the length and width");
       in=new Scanner(System.in);
       length=in.nextDouble();
       width=in.nextDouble();
       Rectangle rob2=new Rectangle(length,width,"blue",false);
       System.out.println("area : "+rob2.getarea()+"  perimeter : "+rob2.getperimeter());
       System.out.println(rob2);
       
       Square sob=new Square();
       System.out.println("area of square : "+sob.getarea()+"perimeter of square : "+sob.getperimeter());
       System.out.println(sob);
       
       System.out.println("enter the side");
       in=new Scanner(System.in);
       side=in.nextDouble();
       Square sob1=new Square(side);
       System.out.println("area of square : "+sob1.getarea()+"perimeter of square : "+sob1.getperimeter());
       System.out.println(sob1);
       
       System.out.println("enter the radius");
       in=new Scanner(System.in);
       side=in.nextDouble();
       Square sob2=new Square(side,"yellow",true);
       System.out.println("area of  square : "+sob2.getarea()+"perimeter of square : "+sob2.getperimeter());
       System.out.println(sob2);
       
       System.out.println("type 'y'/'n' to continue");
                 in=new Scanner(System.in);
                  choice=in.next();

        }while(choice.equals("y"));	

    }
    
}
