/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//12

package reverse_no;
import java.util.Scanner;

/**
 *
 * @author hp
 */
public class Reverse_no {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int rem,var;
        String not;
        do{
            int num,rev=0;
        System.out.println("enter the number");
        Scanner in=new Scanner(System.in);
        num=in.nextInt();
        var=num;
        while(num>0){
           rem=num%10;
           rev=rev*10+rem;
           num/=10;
        }
        System.out.println("the number"+rev);
        System.out.println("type 'y'/'n' to continue");
                Scanner to=new Scanner(System.in);
                  not=to.next();
                
            }while(not.equals("y"));
    }
    
}
