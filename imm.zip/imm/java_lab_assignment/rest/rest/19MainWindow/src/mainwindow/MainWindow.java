/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//19

package mainwindow;

/**
 *
 * @author hp
 */
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JFrame;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;


public class MainWindow extends JFrame implements ActionListener{

	private JMenuBar mnu_bar;
	private JMenu mnu_file;
	private JMenuItem mnu_new, mnu_open, mnu_save, mnu_exit;
	private JTextArea txt_doc;

	
   	MainWindow(String title){

   		super(title);
		
		Container contentPane = getContentPane();

		mnu_bar = new JMenuBar();

		mnu_file = new JMenu("File");

		mnu_new = new JMenuItem("New");
		mnu_new.addActionListener(this);
		mnu_open = new JMenuItem("Open");
		mnu_open.addActionListener(this);
		mnu_save = new JMenuItem("Save");
		mnu_save.addActionListener(this);
		mnu_exit = new JMenuItem("Exit");
		mnu_exit.addActionListener(this);

		mnu_file.add(mnu_new);
		mnu_file.add(mnu_open);
		mnu_file.add(mnu_save);
		mnu_file.addSeparator();
		mnu_file.add(mnu_exit);

		mnu_bar.add(mnu_file);

		setJMenuBar(mnu_bar);
		
		txt_doc = new JTextArea();
		contentPane.add(new JScrollPane(txt_doc), BorderLayout.CENTER);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	    setSize(900,500);
	    setVisible(true);
   	}

   	@Override
	public void actionPerformed(ActionEvent e)
	{
		
		if(e.getSource()==mnu_new){
			txt_doc.setText(" ");

		}
		else if(e.getSource()==mnu_open){
			JFileChooser fc = new JFileChooser("D:\\");
			fc.showOpenDialog(this);
			File f = fc.getSelectedFile();
			BufferedReader br=null;
			try{
			
			 br= new BufferedReader(new FileReader(f));
			String msg=br.readLine();
			while(msg!=null){
				txt_doc.append(msg+"\n");
				msg=br.readLine();

			}
                        
		}
		catch(Exception ex){

		}
                        
		finally{
			try{
				if(br!=null){
					br.close();
				}

			}catch(Exception ex) {

			}
		}

		}
		else if(e.getSource()==mnu_save){
                   /* JFileChooser fileChooser = new JFileChooser();
if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
  File file = fileChooser.getSelectedFile();
  // save to file              
}*/
                   JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Specify a file to save");

		int userSelection = fileChooser.showSaveDialog(this);
		if (userSelection == JFileChooser.APPROVE_OPTION) {
			File fileToSave = fileChooser.getSelectedFile();
			System.out.println("Save as file: " + fileToSave.getAbsolutePath());
    		}
		
	}
        }
	public static void main(String[] args) {
		MainWindow ob = new MainWindow();
           ob.setVisible(true);
		new MainWindow("NotePad....");
	}
}
