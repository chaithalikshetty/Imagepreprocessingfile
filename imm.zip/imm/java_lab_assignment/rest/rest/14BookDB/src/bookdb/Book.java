/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookdb;

/**
 *
 * @author hp
 */
class Book{
	private String author;
	private String title;
	private String publisher;
	private double price;
	private int stock;
	//default constructor
	Book(){
		this.author = "";
		this.title = "";
		this.price=0.0;
		this.publisher="";
		this.stock=0;

	}
	//parameterized constructor
	Book(String author, String title, double price, String publisher,int stock){
		this.author = author;
		this.title = title;
		this.price=price;
		this.publisher=publisher;
		this.stock=stock;

	}
	// to search
	public boolean searchBook(String title, String author){
		if((this.title.equals(title))&&(this.author.equals(author))){
			return true;
		}
            return false;
	}
	@Override
	public String toString(){
		return "price = "+price+" copies = "+stock;

	}
	public int getCopy(){
		return stock;

	}
	public double getPrice(){
		return price;

	}
	public void update(int stock){
		this.stock-=stock;

	}
}