/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//14

package bookdb;

/**
 *
 * @author hp
 */
import java.util.Scanner;
public class BookDB{
	 public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the number of books");
	int num=sc.nextInt();
	Book bookDb[]=new Book[num];
	for(int i=0; i<num;i++){
		System.out.println("Enter book author,title,price,publisher,stock");
		String author = sc.next();
		String title = sc.next();
		double price = sc.nextDouble();
		String publisher = sc.next();
		int stock=sc.nextInt();
		bookDb[i] = new Book(author,title,price,publisher,stock);

	}	

	System.out.println("Searching book......");
	String choice="";
	do{
		System.out.println("Enter title and author = ");
		String title=sc.next();
		String author= sc.next();
		for(int i=0;i<num;i++){
			if(bookDb[i].searchBook(title,author)){
				System.out.println(bookDb[i]);

			     }
			     else{
			     	System.out.println("not found");
			     	break;
                                
			     }
	       /* }
	       for(int i=0;i<num;i++){
	             if(bookDb[i].searchBook(title,author)){
		         System.out.println(bookDb[i]);*/
		      System.out.println("enter the number of copies = ");
		          int copy = sc.nextInt();
		if(copy<=bookDb[i].getCopy()){
			double billAmount = copy*bookDb[i].getPrice();
			bookDb[i].update(copy);
                        System.out.println(billAmount);
			System.out.println("Successfully issued");
			}
			else{
             System.out.println("no sufficient copies");
			}	
		}
	//} 

	     System.out.println("do you wanna search more y/n");
	     choice = sc.next();
        }while(choice.equals("y"));      
	}
}