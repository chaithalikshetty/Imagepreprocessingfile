/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculatordemo;

/**
 *
 * @author hp
 */
/* adaptee */
interface Calculator {
    Calculator put(int n);
    int        read();
    Calculator neg();
    Calculator add();
    Calculator sub();
    Calculator mul();
    Calculator div();
    Calculator clear();
    Calculator clearAll();
}
