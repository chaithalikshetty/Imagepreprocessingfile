/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculatordemo;

/**
 *
 * @author hp
 */
public class Calculatordemo {

    /**
     * @param args the command line arguments
     */
    
    private static void testAdd() {
        Calculator calc = BasicCalculator.getInstance();
           System.out.println("adding");
       System.out.println(calc.put(101)
                   .put(-1)
                   .add()
                   .read() == 100);
System.out.println("adding");
          System.out.println(calc.put(101)
                   .put(-1)
                   .add()
                   .put(2)
                   .sub()
                   .clear()
                   .neg()
                   .read() == -98);
    }

    private static void testDiv() {
        Calculator calc = BasicCalculator.getInstance();
        assert(calc.put(100)
                   .put(2)
                   .div()
                   .put(5)
                   .div()
                   .clear()
                   .neg()
                   .read() == -10);
    }

    private static void testMul() {
        Calculator calc = BasicCalculator.getInstance();
        assert(calc.put(100)
                   .put(2)
                   .mul()
                   .put(-5)
                   .mul()
                   .clear()
                   .neg()
                   .read() == 1000);
    }
    


    public static void main(String args[]) {
        testAdd();
        testDiv();
        testMul();
        
}
}


