/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculatordemo;

/**
 *
 * @author hp
 */
public class BasicCalculator implements Calculator{
      
    int cells[];
    int t=0;

   BasicCalculator() {
        cells = new int[10];
    }

    public Calculator clear() {
        for(int i=1;i<cells.length;i++)
            cells[i]=0;
        return this;	
    }

    public Calculator clearAll() {
        //TODO - Add code here.
        for(int i=0;i<cells.length;i++)
            cells[i]=0;
        return this;	
    }

    public Calculator put(int n) {
        //TODO - Add code here.
        cells[t]=n;
        t++;

        return this;
    }

    public int read() {
        t=0;
        return cells[0];
    }

    public Calculator neg() {
        cells[0]=-cells[0];
        return this;
    }

    public Calculator add() {
        cells[0]=cells[0]+cells[t-1];
        return this;
    }

    public Calculator sub() {
        cells[0]=cells[0]-cells[t-1];
        return this;
    }
    
    public Calculator mul() {
        cells[0]=cells[0]*cells[t-1];
        return this;
    }

    public Calculator div() {
        cells[0]=cells[0]/cells[t-1];
        return this;
    }

    public static Calculator getInstance() {
        Calculator calc = new BasicCalculator();
        calc.clearAll();

        return calc;
    }
}

    

    
    

