/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queuedemo;

/**
 *
 * @author hp
 */
public class Quedm {
    private int front, rear, size;
	private int[] que;
        
    void createNew(int size){
        front =0;
        rear = -1;
		que = new int[size];
		this.size = size;
        
    }
    
    public int add(int data){
		if(rear == size-1){
			System.out.println("overflow...........");
			return 1;
		}
		
                    que[++rear] = data;
                return 1;
			
		
	}
    public int remove(){
		if(front > rear){
			//front = rear = -1;
                        empty();
			return 1;
		}
                /*else{    
                    int ele=que[front];
                    if(front==rear){
                        front=rear=-1;
                    }
                    else
                        front++;
                    return ele;
                    */
			return  que[front++];
                //}
		
	}
    void display(){
         if(front==-1){
            empty();
            return;      
        }
         System.out.println("Queue elements ........");
         for(int i=0;i<=rear;i++){
             System.out.println(que[i]);
         }
         
          
        
    }
    void empty(){
        System.out.println("underflow...........");
    
    }    
}
